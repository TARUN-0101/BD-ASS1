# OOP-First-Assignment-Blood-Donation-Application
The first assignment in our OOP course, by 20bcs006, 20bcs025

This is made with basic python, with only the things we've learnt in college. We've used a .txt file to store data and read() and write() operations to perfom addition of info and display. This entire menu is made using only python and its in built functions


Open the MainMenu.py file for the application
Create an account or use user1 and pass1 to login
